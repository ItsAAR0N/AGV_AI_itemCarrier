# SoftwareSerial for ESP32

Implementation of the Arduino software serial library for the ESP32

Based on the Arduino software serial library for the ESP8266 found here https://github.com/plerup/espsoftwareserial
